<?php
$mod_strings['LBL_CE_LISTVIEW_CONFIGURATION'] = 'ICTBroadcast Configuration for list-views';
$mod_strings['LBL_CE_LISTVIEW_CONFIGURATION_DESCRIPTION'] = 'Enable custom export feature for module list-views.';

$mod_strings['LBL_CE_SUBPANEL_CONFIGURATION'] = 'ICTBroadcast Integration';
$mod_strings['LBL_CE_SUBPANEL_CONFIGURATION_DESCRIPTION'] = 'ICTBroadcast Integration.';

$mod_strings['LBL_CUSTOM_EXPORT_CONF_TAB'] = 'Custom ICTBroadcast Configuration';
$mod_strings['LBL_CUSTOM_EXPORT_CONF_TAB_DESCRIPTION'] = 'ICTBroadcast';

$mod_strings['LBL_CE_EXPORTFIELDS_CONFIGURATION'] = 'Configuration of ICTBroadcast Fields for ListView';
$mod_strings['LBL_CE_EXPORTFIELDS_CONFIGURATION_DESCRIPTION'] = 'ICTBroadcast Integration.';

$mod_strings['LBL_CE_EXPORTFIELDS_SUBPANEL_CONFIGURATION'] = 'ICTBroadcast';
$mod_strings['LBL_CE_EXPORTFIELDS_SUBPANEL_CONFIGURATION_DESCRIPTION'] = 'ICTBroadcast.';