<?php
require_once "include/ListView/ListView.php";

class IctbroadcastSubPanelList extends ListView {

    function process_dynamic_listview($source_module, $sugarbean, $subpanel_def) {
        $this->source_module = $source_module;
        $this->subpanel_module = $subpanel_def->name;
        $this->query_limit = 10000;
        if (!isset($this->xTemplate))
            $this->createXTemplate();

        $html_var = $this->subpanel_module . "_CELL";

        $list_data = $this->processUnionBeans($sugarbean, $subpanel_def, $html_var);

        $list = $list_data['list'];
        $parent_data = $list_data['parent_data'];


        $this->process_dynamic_listview_rows($list, $parent_data, 'dyn_list_view', $html_var, $subpanel_def);

        return $list;
    }

    function processUnionBeans($sugarbean, $subpanel_def, $html_var = 'CELL') {

        $last_detailview_record = $this->getSessionVariable("detailview", "record");
        if (!empty($last_detailview_record) && $last_detailview_record != $sugarbean->id) {
            $GLOBALS['record_has_changed'] = true;
        }
        $this->setSessionVariable("detailview", "record", $sugarbean->id);

        $current_offset = $this->getOffset($html_var);
        $module = isset($_REQUEST['module']) ? $_REQUEST['module'] : '';
        $response = array();

        $this->sort_order = 'asc';
        if (isset($_REQUEST['sort_order'])) {
            $this->sort_order = $_REQUEST['sort_order'];
        } else {
            if (isset($subpanel_def->_instance_properties['sort_order'])) {
                $sort_order = $subpanel_def->_instance_properties['sort_order'];
            }

            if (isset($_SESSION['last_sub' . $this->subpanel_module . '_order'])) {
                // We swap the order when the request contains an offset (indicating a column sort issued);
                // otherwise we do not sort.  If we don't make this check, then the subpanel listview will
                // swap ordering each time a new record is entered via quick create forms

                if (isset($_REQUEST[$module . '_' . $html_var . '_offset'])) {
                    $this->sort_order = $_SESSION['last_sub' . $this->subpanel_module . '_order'] == 'asc' ? 'desc' : 'asc';
                } else {
                    $this->sort_order = $_SESSION['last_sub' . $this->subpanel_module . '_order'];
                }
            } elseif (isset($sort_order)) {
                $this->sort_order = $sort_order;
            }
        }


        if (isset($subpanel_def->_instance_properties['sort_by']))
            $this->query_orderby = $subpanel_def->_instance_properties['sort_by'];
        else
            $this->query_orderby = 'id';

        $this->getOrderBy($html_var, $this->query_orderby, $this->sort_order);

        $_SESSION['last_sub' . $this->subpanel_module . '_order'] = $this->sort_order;
        $_SESSION['last_sub' . $this->subpanel_module . '_url'] = $this->getBaseURL($html_var);


        if (!empty($this->response)) {
            $response = & $this->response;
            echo 'cached';
        } else {
            $response = SugarBean::get_union_related_list($sugarbean, $this->sortby, $this->sort_order, $this->query_where, $current_offset, $this->query_limit, $this->query_limit, 0, $subpanel_def);
            $this->response = & $response;
        }
        $list = $response['list'];
        $row_count = $response['row_count'];
        $next_offset = $response['next_offset'];
        $previous_offset = $response['previous_offset'];
        if (!empty($response['current_offset']))
            $current_offset = $response['current_offset'];
        global $list_view_row_count;
        $list_view_row_count = $row_count;

        return array('list' => $list, 'parent_data' => $response['parent_data'], 'query' => $response['query']);
    }

    function process_dynamic_listview_rows($data, $parent_data, $xtemplateSection, $html_varName, $subpanel_def) {
        $count = 0;
        reset($data);

        $processed_ids = array();

        $fill_additional_fields = array();
        //Either retrieve the is_fill_in_additional_fields property from the lone
        //subpanel or visit each subpanel's subpanels to retreive the is_fill_in_addition_fields
        //property
        $subpanel_list = array();
        if ($subpanel_def->isCollection()) {
            $subpanel_list = $subpanel_def->sub_subpanels;
        } else {
            $subpanel_list[] = $subpanel_def;
        }

        foreach ($subpanel_list as $this_subpanel) {
            if ($this_subpanel->is_fill_in_additional_fields()) {
                $fill_additional_fields[] = $this_subpanel->bean_name;
                $fill_additional_fields[$this_subpanel->bean_name] = true;
            }
        }

        if (empty($data)) {
            $thepanel = $subpanel_def;
            if ($subpanel_def->isCollection())
                $thepanel = $subpanel_def->get_header_panel_def();
        }

        while (list($aVal, $aItem) = each($data)) {
            $aItem->check_date_relationships_load();
            // TODO: expensive and needs to be removed and done better elsewhere

            if (!empty($fill_additional_fields[$aItem->object_name])
                    || ($aItem->object_name == 'Case' && !empty($fill_additional_fields['aCase']))
            ) {
                $aItem->fill_in_additional_list_fields();
            }
            //rrs bug: 25343
            $aItem->call_custom_logic("process_record");

            if (isset($parent_data[$aItem->id])) {

                $aItem->parent_name = $parent_data[$aItem->id]['parent_name'];
                if (!empty($parent_data[$aItem->id]['parent_name_owner'])) {
                    $aItem->parent_name_owner = $parent_data[$aItem->id]['parent_name_owner'];
                    $aItem->parent_name_mod = $parent_data[$aItem->id]['parent_name_mod'];
                }
            }

            $fields = $aItem->get_list_view_data();
            if (isset($processed_ids[$aItem->id])) {
                continue;
            } else {
                $processed_ids[$aItem->id] = 1;
            }

            $count++;
        }
    }

}

?>