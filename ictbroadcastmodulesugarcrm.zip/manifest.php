<?php

global $sugar_version, $sugar_flavor;

$manifest = array(
    'acceptable_sugar_flavors' => array('CE', 'PRO'),
    'acceptable_sugar_versions' => array(
        'regex_matches' => array(
            0 => "6.3.*",
            1 => "6.4.*",
            2 => "6.5.*",
        ),
    ),
    'readme' => '',
    'key' => 'bc',
    'author' => 'adeel sharif',
    'description' => 'ICTVission',
    'icon' => '',
    'is_uninstallable' => true,
    'name' => '',
    'published_date' => '2016-11-08 00:00:00',
    'type' => 'module',
    'version' => '1.1.3',
    'remove_tables' => 'prompt',
);

$installdefs = array(
    'id' => 'SugarCRM_ictbroadcast',
    'beans' =>
    array(
        0 =>
        array(
            'module' => 'CE_custom_ictbroadcast',
            'class' => 'CE_custom_ictbroadcast',
            'path' => 'modules/CE_custom_ictbroadcast/CE_custom_ictbroadcast.php',
            'tab' => false,
        ),
    ),
    'image_dir' => '<basepath>/icons',
    'pre_execute' => array(
        0 => '<basepath>/scripts/pre_execute.php',
    ),
    'post_uninstall' => array(
        0 => '<basepath>/scripts/post_uninstall.php',
    ),
    'copy' =>
    array(
        0 =>
        array(
            'from' => '<basepath>/SugarModules/custom/Extension/modules/Administration/Ext/Administration/ce_config_tab.php',
            'to' => 'custom/Extension/modules/Administration/Ext/Administration/ce_config_tab.php',
        ),
        1 =>
        array(
            'from' => '<basepath>/SugarModules/custom/Extension/modules/Administration/Ext/Language/en_us.ce_config_tab.php',
            'to' => 'custom/Extension/modules/Administration/Ext/Language/en_us.ce_config_tab.php',
        ),
        2 =>
        array(
            'from' => '<basepath>/SugarModules/custom/Extension/application/Ext/EntryPointRegistry/customIctbroadcast_EntryPoint.php',
            'to' => 'custom/Extension/application/Ext/EntryPointRegistry/customIctbroadcast_EntryPoint.php',
        ),
        3 =>
        array(
            'from' => '<basepath>/SugarModules/custom/include/generic/SugarWidgets/SugarWidgetSubPanelTopIctbroadcastBtn.php',
            'to' => 'custom/include/generic/SugarWidgets/SugarWidgetSubPanelTopIctbroadcastBtn.php',
        ),
       
        4 =>
        array(
            'from' => '<basepath>/SugarModules/modules/CE_custom_ictbroadcast',
            'to' => 'modules/CE_custom_ictbroadcast',
        ),
    ),
    'language' =>
    array(
        0 =>
        array(
            'from' => '<basepath>/SugarModules/language/application/en_us.lang.php',
            'to_module' => 'application',
            'language' => 'en_us',
        ),
    ),
);

$re_sugar63 = '/(6\.3\.[0-9])/';
$re_sugar64 = '/(6\.4\.[0-9])/';
$re_sugar65 = '/(6\.5\.[0-9])/';
$re_sugar6519 = '/(6\.5\.19\)/';
$re_sugar6520 = '/(6\.5\.20\)/';

if (preg_match($re_sugar63, $sugar_version)) {
    $GLOBALS['log']->fatal('Installation Version step 1:-' . $sugar_version);
    array_push($installdefs['copy'], array(
        'from' => '<basepath>/SugarModules/Diff_ViewFile/sugar_63_633/view.list.php',
        'to' => 'include/MVC/View/views/view.list.php',
    ));
}
if (preg_match($re_sugar64, $sugar_version)) {
    $GLOBALS['log']->fatal('Installation Version step 2:-' . $sugar_version);
    array_push($installdefs['copy'], array(
        'from' => '<basepath>/SugarModules/Diff_ViewFile/sugar_64_646/view.list.php',
        'to' => 'include/MVC/View/views/view.list.php',
    ));
}
if (preg_match($re_sugar65, $sugar_version)) {
    $GLOBALS['log']->fatal('Installation Version step 3:-' . $sugar_version);
    if (preg_match($re_sugar6519, $sugar_version) || preg_match($re_sugar6520, $sugar_version)) {
        array_push($installdefs['copy'], array(
            'from' => '<basepath>/SugarModules/Diff_ViewFile/sugar_6519_6520/view.list.php',
            'to' => 'include/MVC/View/views/view.list.php',
        ));
    } else {
        array_push($installdefs['copy'], array(
            'from' => '<basepath>/SugarModules/Diff_ViewFile/sugar_652_6518/view.list.php',
            'to' => 'include/MVC/View/views/view.list.php',
        ));
    }
}
