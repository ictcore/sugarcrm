<?php

if (!defined('sugarEntry'))
    define('sugarEntry', true);
pre_execute();
install_sql();

function pre_execute() {
    $file = 'include/MVC/View/views/view.list.php';
    $newfile = 'include/MVC/View/views/view.list_cebkp.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    
    
    // backup custom view.list for Apply custom ictbroadcast code.
    $file = 'custom/modules/Accounts/views/view.list.php';
    $newfile = 'custom/modules/Accounts/views/view.list_cebkp.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    
    $file = 'custom/modules/Cases/views/view.list.php';
    $newfile = 'custom/modules/Cases/views/view.list_cebkp.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Contacts/views/view.list.php';
    $newfile = 'custom/modules/Contacts/views/view.list_cebkp.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Leads/views/view.list.php';
    $newfile = 'custom/modules/Leads/views/view.list_cebkp.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Meetings/views/view.list.php';
    $newfile = 'custom/modules/Meetings/views/view.list_cebkp.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Opportunities/views/view.list.php';
    $newfile = 'custom/modules/Opportunities/views/view.list_cebkp.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Project/views/view.list.php';
    $newfile = 'custom/modules/Project/views/view.list_cebkp.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Prospects/views/view.list.php';
    $newfile = 'custom/modules/Prospects/views/view.list_cebkp.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
}

function install_sql() {
    global $db;

    // For Create custom ictbroadcast table for listview :-- 
    $sql1 = "CREATE TABLE IF NOT EXISTS custom_ictbroadcast_modules_tbl (
                id char(36) NOT NULL,
                module varchar(255) NOT NULL,
                date_created datetime NOT NULL
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

    $db->query($sql1);
    
     // For Create custom ictbroadcast table for subpanel :-- 
    $sql2 = "CREATE TABLE IF NOT EXISTS custom_ictbroadcast_subpanel_tbl (
                id char(36) NOT NULL,
                module varchar(255) NOT NULL,
                subpanel varchar(255) NOT NULL,
                date_created datetime NOT NULL
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

    $db->query($sql2);
    
     $sql3 = "CREATE TABLE IF NOT EXISTS custom_ictbroadcast_integration_tbl (
                id char(36) NOT NULL,
                link varchar(255) NOT NULL,
                token text,
                date_created datetime NOT NULL
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

    $db->query($sql3);
}
